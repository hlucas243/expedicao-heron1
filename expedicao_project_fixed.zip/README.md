# Expedição App
Sistema de controle de OPs para expedição com banco offline.

Funções:
- Entrada de OP com foto
- Divisão por corredores
- Saída e pesquisa de OPs
- Tema escuro industrial
- 100% offline

Banco: SQLite
Pasta de fotos: /sdcard/ExpedicaoFotos
Compatível com: Pydroid 3
